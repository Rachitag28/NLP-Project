import nltk
import collections
from collections import Counter
import random
from nltk.collocations import BigramCollocationFinder
from nltk.metrics import BigramAssocMeasures
from nltk.classify.scikitlearn import SklearnClassifier
from sklearn.naive_bayes import MultinomialNB
from sklearn.svm import SVC, LinearSVC
from sklearn import metrics

document=open('C:\\Users\\user\\Desktop\\NLP\\NLP Project\\Special\\semeval2016-task6-trainingdata.txt',"r").read()
tuples=document.split('\n')
ids=[]
targets=[]
tweets=[]
stances=[]
for t in tuples:
	ids.append(t.split('\t')[0])
	targets.append(t.split('\t')[1])
	tweets.append(t.split('\t')[2])
	stances.append(t.split('\t')[3])
ids=ids[1:]
targets=targets[1:]
tweets=tweets[1:]
stances=stances[1:]

clean_tweets=[]
document2=open('C:\\Users\\user\\Desktop\\NLP\\NLP Project\\Special\\Final_training_tweet.txt',"r").read()
tuples2=document2.split('\n')
for t2 in tuples2:
	clean_tweets.append(t2)

tweets_with_labels=list(zip(clean_tweets, stances))
##tweets_with_labels_atheism=tweets_with_labels[0:513]

all_bigrams=[]
all_bigrams=[b for t in clean_tweets for b in zip(t.split(" ")[:-1], t.split(" ")[1:])]
b_features=Counter(all_bigrams).most_common(5000)
bigram_features=[]
for (bigram,freq) in b_features:
	bigram_features.append(bigram)

def find_features(single_tweet):
	words=set(single_tweet)
	features={}
	for w in bigram_features:
		features[w]=(w in words)
	return features

featuresets=[(find_features(tweets), stances) for (tweets, stances) in tweets_with_labels]
training_set_atheism=featuresets[1:513]
random.shuffle(training_set_atheism)
training_set_climate=featuresets[514:908]
random.shuffle(training_set_climate)
training_set_feminist=featuresets[909:1572]
random.shuffle(training_set_feminist)
training_set_hillary=featuresets[1573:2211]
random.shuffle(training_set_hillary)
training_set_abortion=featuresets[2212:2814]
random.shuffle(training_set_abortion)


MNB_atheism=SklearnClassifier(MultinomialNB())
MNB_atheism.train(training_set_atheism)
MNB_climate=SklearnClassifier(MultinomialNB())
MNB_climate.train(training_set_climate)
MNB_feminist=SklearnClassifier(MultinomialNB())
MNB_feminist.train(training_set_feminist)
MNB_hillary=SklearnClassifier(MultinomialNB())
MNB_hillary.train(training_set_hillary)
MNB_abortion=SklearnClassifier(MultinomialNB())
MNB_abortion.train(training_set_abortion)
####print("MNB_classifier accuracy percentage:",(nltk.classify.accuracy(MNB_classifier,testing_set))*100)
##SVC_classifier=SklearnClassifier(SVC())
##SVC_classifier.train(training_set)
####print("SVC_classifier accuracy percentage:",(nltk.classify.accuracy(SVC_classifier,testing_set))*100)


clean_tweets_testing=[]
document3=open('C:\\Users\\user\\Desktop\\NLP\\NLP Project\\Special\\Final_testing_tweet.txt',"r").read()
tuples3=document3.split('\n')
for t3 in tuples3:
        clean_tweets_testing.append(t3)
		
document=open('C:\\Users\\user\\Desktop\\NLP\\NLP Project\\Special\\SemEval2016-Task6-subtaskA-testdata-gold.txt',"r").read()
tuples4=document.split('\n')
real_labels=[]
for t in tuples4:
	real_labels.append(t.split('\t')[3])

testing_tweets_with_labels=list(zip(clean_tweets_testing, real_labels))
featuresets_test=[(find_features(tweets), stances) for (tweets, stances) in testing_tweets_with_labels]
fea,real_label=zip(*featuresets_test)
testing_features_atheism=featuresets_test[1:220]
random.shuffle(testing_features_atheism)
testing_features_climate=featuresets_test[221:389]
random.shuffle(testing_features_climate)
testing_features_feminist=featuresets_test[390:674]
random.shuffle(testing_features_feminist)
testing_features_hillary=featuresets_test[675:969]
random.shuffle(testing_features_hillary)
testing_features_abortion=featuresets_test[970:1249]
random.shuffle(testing_features_abortion)
print("MNB_classifier accuracy percentage for target Atheism:",(nltk.classify.accuracy(MNB_atheism,testing_features_atheism))*100)
print("MNB_classifier accuracy percentage for target Climate Change is a Real Concern:",(nltk.classify.accuracy(MNB_climate,testing_features_climate))*100)
print("MNB_classifier accuracy percentage for target Feminist Movement:",(nltk.classify.accuracy(MNB_feminist,testing_features_feminist))*100)
print("MNB_classifier accuracy percentage for target Hillary Clinton:",(nltk.classify.accuracy(MNB_hillary,testing_features_hillary))*100)
print("MNB_classifier accuracy percentage for Legalization of Abortion:",(nltk.classify.accuracy(MNB_abortion,testing_features_abortion))*100)
##features, labels=zip(*testing_features_hillary)
##pred_labels=MNB_hillary.classify_many(features)
##print(pred_labels)



